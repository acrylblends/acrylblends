import type { UpgradeWebSocket, WSContext } from '../../../acryl-router/src/helpers/index.ts'
import { defineWebSocketHelper } from '../../../acryl-router/src/helpers/index.ts'
import type { IncomingMessage } from 'node:http'
import { STATUS_CODES } from 'node:http'
import type { Duplex } from 'node:stream'
import type { FetchCallback, ServerType } from './types.ts'
import type { WebSocketData, WebSocketLike, WebSocketServerLike } from './websocket-types.ts'

interface CloseEventInit extends EventInit {
  code?: number
  reason?: string
  wasClean?: boolean
}

/**
 * @link https://developer.mozilla.org/en-US/docs/Web/API/CloseEvent
 */
export const CloseEvent: typeof globalThis.CloseEvent =
  globalThis.CloseEvent ??
  class extends Event {
    #eventInitDict

    constructor(type: string, eventInitDict: CloseEventInit = {}) {
      super(type, eventInitDict)
      this.#eventInitDict = eventInitDict
    }

    get wasClean(): boolean {
      return this.#eventInitDict.wasClean ?? false
    }

    get code(): number {
      return this.#eventInitDict.code ?? 0
    }

    get reason(): string {
      return this.#eventInitDict.reason ?? ''
    }
  }

interface ErrorEventInit extends EventInit {
  message?: string
  filename?: string
  lineno?: number
  colno?: number
  error?: unknown
}

/**
 * Node.js has no global `ErrorEvent`, unlike `Event`/`MessageEvent`/`CloseEvent`.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/ErrorEvent
 */
export const ErrorEvent: typeof globalThis.ErrorEvent =
  globalThis.ErrorEvent ??
  class extends Event {
    #eventInitDict

    constructor(type: string, eventInitDict: ErrorEventInit = {}) {
      super(type, eventInitDict)
      this.#eventInitDict = eventInitDict
    }

    get message(): string {
      return this.#eventInitDict.message ?? ''
    }

    get filename(): string {
      return this.#eventInitDict.filename ?? ''
    }

    get lineno(): number {
      return this.#eventInitDict.lineno ?? 0
    }

    get colno(): number {
      return this.#eventInitDict.colno ?? 0
    }

    get error(): unknown {
      return this.#eventInitDict.error ?? null
    }
  }

const generateConnectionSymbol = () => Symbol('connection')

type WaitForWebSocket = (
  request: IncomingMessage,
  connectionSymbol: symbol
) => Promise<WebSocketLike>

const CONNECTION_SYMBOL_KEY: unique symbol = Symbol('CONNECTION_SYMBOL_KEY')
const WAIT_FOR_WEBSOCKET_SYMBOL: unique symbol = Symbol('WAIT_FOR_WEBSOCKET_SYMBOL')

export type UpgradeBindings = {
  incoming: IncomingMessage
  outgoing: undefined
  wss: WebSocketServerLike
  [CONNECTION_SYMBOL_KEY]?: symbol
  [WAIT_FOR_WEBSOCKET_SYMBOL]?: WaitForWebSocket
}

type UpgradeWebSocketOptions = {
  onError: (err: unknown) => void
}

// Hop-by-hop headers per RFC 9110 Section 7.6.1
// (https://www.rfc-editor.org/rfc/rfc9110.html#name-connection) plus
// `keep-alive` (commonly treated as hop-by-hop by HTTP implementations) and
// WebSocket handshake headers managed by `ws` itself. These must not be
// forwarded onto the upgrade response or the handshake will be corrupted.
const responseHeadersToSkip = new Set([
  'connection',
  'content-length',
  'keep-alive',
  'proxy-authenticate',
  'proxy-authorization',
  'te',
  'trailer',
  'transfer-encoding',
  'upgrade',
  'sec-websocket-accept',
  'sec-websocket-extensions',
  'sec-websocket-protocol',
])

const appendResponseHeaders = (headers: string[], responseHeaders?: Headers) => {
  if (!responseHeaders) {
    return
  }
  responseHeaders.forEach((value, key) => {
    if (responseHeadersToSkip.has(key.toLowerCase())) {
      return
    }
    headers.push(`${key}: ${value}`)
  })
}

const rejectUpgradeRequest = (socket: Duplex, status: number, responseHeaders?: Headers) => {
  const responseLines = ['Connection: close', 'Content-Length: 0']
  appendResponseHeaders(responseLines, responseHeaders)

  socket.end(
    `HTTP/1.1 ${status.toString()} ${STATUS_CODES[status] ?? ''}\r\n` +
      `${responseLines.join('\r\n')}\r\n` +
      '\r\n'
  )
}

const createUpgradeRequest = (request: IncomingMessage): Request => {
  const protocol = (request.socket as { encrypted?: boolean }).encrypted ? 'https' : 'http'
  const url = new URL(request.url ?? '/', `${protocol}://${request.headers.host ?? 'localhost'}`)
  const headers = new Headers()
  for (const key in request.headers) {
    const value = request.headers[key]
    if (!value) {
      continue
    }
    headers.append(key, Array.isArray(value) ? value[0] : value)
  }
  return new Request(url, {
    headers,
  })
}

export const setupWebSocket = (options: {
  server: ServerType
  fetchCallback: FetchCallback
  wss: WebSocketServerLike
}): void => {
  const { server, fetchCallback, wss } = options

  const waiterMap = new Map<
    IncomingMessage,
    {
      resolve: (ws: WebSocketLike) => void
      reject: (reason: Error) => void
      connectionSymbol: symbol
    }
  >()

  wss.on('connection', (ws, request) => {
    const waiter = waiterMap.get(request)
    if (waiter) {
      waiter.resolve(ws)
      waiterMap.delete(request)
    }
  })

  const rejectWaiter = (request: IncomingMessage) => {
    const waiter = waiterMap.get(request)
    if (waiter) {
      waiterMap.delete(request)
      waiter.reject(new Error('WebSocket handshake aborted'))
    }
  }

  const waitForWebSocket: WaitForWebSocket = (request, connectionSymbol) => {
    return new Promise<WebSocketLike>((resolve, reject) => {
      waiterMap.set(request, { resolve, reject, connectionSymbol })
    })
  }

  server.on('upgrade', async (request, socket: Duplex, head) => {
    if (request.headers.upgrade?.toLowerCase() !== 'websocket') {
      return
    }

    const env: UpgradeBindings = {
      incoming: request,
      outgoing: undefined,
      wss,
      [WAIT_FOR_WEBSOCKET_SYMBOL]: waitForWebSocket,
    }

    let status = 400
    let responseHeaders: Headers | undefined
    try {
      const response = (await fetchCallback(
        createUpgradeRequest(request),
        env as unknown as Parameters<FetchCallback>[1]
      )) as Response
      if (response instanceof Response) {
        status = response.status
        responseHeaders = response.headers
      }
    } catch {
      if (server.listenerCount('upgrade') === 1) {
        rejectUpgradeRequest(socket, 500)
      }
      return
    }

    const waiter = waiterMap.get(request)

    if (!waiter || waiter.connectionSymbol !== env[CONNECTION_SYMBOL_KEY]) {
      rejectWaiter(request)
      if (server.listenerCount('upgrade') === 1) {
        rejectUpgradeRequest(socket, status, responseHeaders)
      }
      return
    }

    const addResponseHeaders = (headers: string[]) => {
      appendResponseHeaders(headers, responseHeaders)
    }

    const reclaimWaiterOnClose = () => rejectWaiter(request)
    socket.once('close', reclaimWaiterOnClose)

    wss.on('headers', addResponseHeaders)
    try {
      wss.handleUpgrade(request, socket, head, (ws) => {
        socket.off('close', reclaimWaiterOnClose)
        wss.emit('connection', ws, request)
      })
    } finally {
      wss.off('headers', addResponseHeaders)
    }
  })

  server.on('close', () => {
    wss.close()
  })
}

export const upgradeWebSocket: UpgradeWebSocket<WebSocketLike, UpgradeWebSocketOptions> =
  defineWebSocketHelper(async (c, events, options) => {
    if (c.req.header('upgrade')?.toLowerCase() !== 'websocket') {
      return
    }

    const env = c.env as UpgradeBindings
    const waitForWebSocket = env[WAIT_FOR_WEBSOCKET_SYMBOL]

    if (!waitForWebSocket || !env.incoming) {
      return new Response(null, { status: 500 })
    }

    const connectionSymbol = generateConnectionSymbol()
    env[CONNECTION_SYMBOL_KEY] = connectionSymbol
    ;(async () => {
      let ws: WebSocketLike
      try {
        ws = await waitForWebSocket(env.incoming, connectionSymbol)
      } catch {
        return
      }

      const messagesReceivedInStarting: [data: WebSocketData, isBinary: boolean][] = []
      const bufferMessage = (data: WebSocketData, isBinary: boolean) => {
        messagesReceivedInStarting.push([data, isBinary])
      }
      ws.on('message', bufferMessage)

      // A plain object with the class's public shape: the class's private field is not part of the shape, so it is asserted once.
      const shape: Pick<WSContext<WebSocketLike>, keyof WSContext<WebSocketLike>> = {
        binaryType: 'arraybuffer',
        close(code, reason) {
          ws.close(code, reason)
        },
        protocol: ws.protocol,
        raw: ws,
        get readyState() {
          return ws.readyState
        },
        send(source, opts) {
          ws.send(source, {
            compress: opts?.compress,
          })
        },
        url: new URL(c.req.url),
      }
      const ctx = shape as WSContext<WebSocketLike>

      try {
        events?.onOpen?.(new Event('open'), ctx)
      } catch (e) {
        ;(options?.onError ?? console.error)(e)
      }

      const handleMessage = (data: WebSocketData, isBinary: boolean) => {
        const datas = Array.isArray(data) ? data : [data]
        for (const data of datas) {
          try {
            events?.onMessage?.(
              new MessageEvent('message', {
                data: isBinary
                  ? data instanceof ArrayBuffer
                    ? data
                    : data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength)
                  : typeof data === 'string'
                    ? data
                    : Buffer.from(data).toString('utf-8'),
              }),
              ctx
            )
          } catch (e) {
            ;(options?.onError ?? console.error)(e)
          }
        }
      }

      ws.off('message', bufferMessage)
      for (const message of messagesReceivedInStarting) {
        handleMessage(...message)
      }

      ws.on('message', (data, isBinary) => {
        handleMessage(data, isBinary)
      })

      ws.on('close', (code, reason) => {
        try {
          events?.onClose?.(new CloseEvent('close', { code, reason: reason.toString() }), ctx)
        } catch (e) {
          ;(options?.onError ?? console.error)(e)
        }
      })

      ws.on('error', (error) => {
        try {
          events?.onError?.(
            new ErrorEvent('error', {
              error,
            }),
            ctx
          )
        } catch (e) {
          ;(options?.onError ?? console.error)(e)
        }
      })
    })()

    return new Response()
  })
