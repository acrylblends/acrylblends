import type { HtmlEscaped, HtmlEscapedString, StringBufferWithCallbacks } from '../utils/html.ts';
import { DOM_MEMO } from './constants.ts';
import type { Context } from './context.ts';
import type { JSX as AcrylJSX } from './intrinsic-elements.ts';
export type Props = Record<string, any>;
type FunctionComponentResult = HtmlEscapedString | JSXNode | Child[] | Promise<HtmlEscapedString | JSXNode | Child[]> | null;
export type FC<P = Props> = {
    (props: P): FunctionComponentResult;
    defaultProps?: Partial<P> | undefined;
    displayName?: string | undefined;
};
export type DOMAttributes = AcrylJSX.HTMLAttributes;
export declare namespace JSX {
    type Element = HtmlEscapedString | Promise<HtmlEscapedString>;
    type ElementType = string | ((props: never) => FunctionComponentResult);
    interface ElementChildrenAttribute {
        children: Child;
    }
    interface IntrinsicElements extends AcrylJSX.IntrinsicElements {
        [tagName: string]: Props;
    }
    interface IntrinsicAttributes {
        key?: string | number | bigint | null | undefined;
    }
}
export declare const getNameSpaceContext: () => Context<string> | undefined;
export declare const booleanAttributes: string[];
export type Child = string | Promise<string> | number | JSXNode | null | undefined | boolean | Child[];
export declare const renderChildren: (children: Child[]) => HtmlEscapedString | Promise<HtmlEscapedString>;
export declare const isUntrustedObject: (value: unknown) => boolean;
export declare const renderUntrustedObject: (value: unknown) => HtmlEscapedString | Promise<HtmlEscapedString>;
export declare class JSXNode implements HtmlEscaped {
    tag: string | Function;
    props: Props;
    key?: string;
    children: Child[];
    isEscaped: true;
    constructor(tag: string | Function, props: Props, children: Child[]);
    get type(): string | Function;
    get ref(): any;
    toString(): string | Promise<string>;
    toStringToBuffer(buffer: StringBufferWithCallbacks): void;
}
export declare class JSXFragmentNode extends JSXNode {
    toStringToBuffer(buffer: StringBufferWithCallbacks): void;
}
export declare const jsx: (tag: string | Function, props: Props | null, ...children: Child[]) => JSXNode;
export declare const jsxFn: (tag: string | Function, props: Props, children: Child[]) => JSXNode;
export declare const shallowEqual: (a: Props, b: Props) => boolean;
export type MemorableFC<T> = FC<T> & {
    [DOM_MEMO]: (prevProps: Readonly<T>, nextProps: Readonly<T>) => boolean;
};
export declare const memo: <T>(component: FC<T>, propsAreEqual?: (prevProps: Readonly<T>, nextProps: Readonly<T>) => boolean) => FC<T>;
export declare const Fragment: ({ children, }: {
    key?: string;
    children?: Child | HtmlEscapedString;
}) => HtmlEscapedString;
export declare const isValidElement: (element: unknown) => element is JSXNode;
export declare const cloneElement: <T extends JSXNode | JSX.Element>(element: T, props: Partial<Props>, ...children: Child[]) => T;
export declare const reactAPICompatVersion = "19.0.0-acryl-jsx";
export {};
