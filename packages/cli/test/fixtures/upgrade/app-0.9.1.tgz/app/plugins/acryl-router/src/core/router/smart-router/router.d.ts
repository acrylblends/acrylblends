import type { Result, Router } from '../../router.ts';
export declare class SmartRouter<T> implements Router<T> {
    #private;
    name: string;
    constructor(init: {
        routers: Router<T>[];
    });
    add(method: string, path: string, handler: T): void;
    match(method: string, path: string): Result<T>;
    get activeRouter(): Router<T>;
}
