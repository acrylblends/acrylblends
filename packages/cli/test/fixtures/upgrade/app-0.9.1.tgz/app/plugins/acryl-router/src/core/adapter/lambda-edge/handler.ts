import crypto from 'node:crypto'
import type { Acryl } from '../../app.ts'
import { decodeBase64, encodeBase64 } from '../../utils/encode.ts'

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
globalThis.crypto ??= crypto

interface CloudFrontHeader {
  key: string
  value: string
}

interface CloudFrontHeaders {
  [name: string]: CloudFrontHeader[]
}

interface CloudFrontCustomOrigin {
  customHeaders: CloudFrontHeaders
  domainName: string
  keepaliveTimeout: number
  path: string
  port: number
  protocol: string
  readTimeout: number
  sslProtocols: string[]
}
// https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/lambda-event-structure.html
interface CloudFrontS3Origin {
  authMethod: 'origin-access-identity' | 'none'
  customHeaders: CloudFrontHeaders
  domainName: string
  path: string
  region: string
}
type CloudFrontOrigin =
  | { s3: CloudFrontS3Origin; custom?: never }
  | { custom: CloudFrontCustomOrigin; s3?: never }

export interface CloudFrontRequest {
  clientIp: string
  headers: CloudFrontHeaders
  method: string
  querystring: string
  uri: string
  body?: {
    inputTruncated: boolean
    action: string
    encoding: string
    data: string
  }
  origin?: CloudFrontOrigin
}

export interface CloudFrontResponse {
  headers: CloudFrontHeaders
  status: string
  statusDescription?: string
}

export interface CloudFrontConfig {
  distributionDomainName: string
  distributionId: string
  eventType: string
  requestId: string
}

interface CloudFrontEvent {
  cf: {
    config: CloudFrontConfig
    request: CloudFrontRequest
    response?: CloudFrontResponse
  }
}

export interface CloudFrontEdgeEvent {
  Records: CloudFrontEvent[]
}

type CloudFrontContext = {}

export interface Callback {
  (err: Error | null, result?: CloudFrontRequest | CloudFrontResult): void
}

// https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/lambda-generating-http-responses-in-requests.html#lambda-generating-http-responses-programming-model
interface CloudFrontResult {
  status: string
  statusDescription?: string
  headers?: {
    [header: string]: {
      key: string
      value: string
    }[]
  }
  body?: string
  bodyEncoding?: 'text' | 'base64'
}

/**
 * Accepts events from 'Lambda@Edge' event
 * https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/lambda-event-structure.html
 */
const convertHeaders = (headers: Headers): CloudFrontHeaders => {
  const cfHeaders: CloudFrontHeaders = {}
  headers.forEach((value, key) => {
    cfHeaders[key.toLowerCase()] = [
      ...(cfHeaders[key.toLowerCase()] || []),
      { key: key.toLowerCase(), value },
    ]
  })
  return cfHeaders
}

export const handle = (
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  app: Acryl<any>
): ((
  event: CloudFrontEdgeEvent,
  context?: CloudFrontContext,
  callback?: Callback
) => Promise<CloudFrontResult | CloudFrontRequest>) => {
  return async (event, ...args: [context?: CloudFrontContext, callback?: Callback]) => {
    const [context, callback] = args
    let callbackError: Error | null = null
    let callbackResult: CloudFrontResult | CloudFrontRequest | undefined
    const cf = getCloudFrontRecord(event)
    const res = await app.fetch(createRequest(cf), {
      event,
      context,
      callback: (err: Error | null, result?: CloudFrontResult | CloudFrontRequest) => {
        if (!callbackError && !callbackResult) {
          callbackError = err
          callbackResult = result
        }
        callback?.(err, result)
      },
      config: cf.config,
      request: cf.request,
      response: cf.response,
    })
    if (callbackError) {
      throw callbackError
    }
    return callbackResult ?? createResult(res)
  }
}

const createResult = async (res: Response): Promise<CloudFrontResult> => {
  const contentEncoding = res.headers.get('content-encoding')
  const isBase64Encoded =
    isContentTypeBinary(res.headers.get('content-type') || '') ||
    (!!contentEncoding && !/^identity$/i.test(contentEncoding))
  const body = isBase64Encoded ? encodeBase64(await res.arrayBuffer()) : await res.text()

  return {
    status: res.status.toString(),
    headers: convertHeaders(res.headers),
    body,
    ...(isBase64Encoded && { bodyEncoding: 'base64' }),
  }
}

/**
 * Reads the CloudFront record out of a Lambda@Edge event.
 *
 * The event is supplied by the runtime, so a malformed one means the function
 * was invoked with something other than a Lambda@Edge event. Fail with a
 * message naming the adapter and the missing field, rather than letting an
 * unattributable property access error escape.
 */
const getCloudFrontRecord = (event: CloudFrontEdgeEvent): CloudFrontEvent['cf'] => {
  const cf = event?.Records?.[0]?.cf
  if (!cf?.request) {
    throw new TypeError(
      'Unable to map the CloudFront event to a Request: expected `Records[0].cf.request` in the Lambda@Edge event.'
    )
  }
  return cf
}

const createRequest = (cf: CloudFrontEvent['cf']): Request => {
  const request = cf.request
  const queryString = request.querystring
  const host = request.headers?.host?.[0]?.value || cf.config?.distributionDomainName
  const urlPath = `https://${host}${request.uri}`
  const url = queryString ? `${urlPath}?${queryString}` : urlPath

  const headers = new Headers()
  Object.entries(request.headers ?? {}).forEach(([k, v]) => {
    v.forEach((header) => headers.append(k, header.value))
  })

  const requestBody = request.body
  const method = request.method
  const rawBody = createBody(method, requestBody)

  let body: string | Uint8Array<ArrayBuffer> | undefined = rawBody
  if (rawBody !== undefined) {
    const bytes =
      typeof rawBody === 'string'
        ? (new TextEncoder().encode(rawBody) as Uint8Array<ArrayBuffer>)
        : rawBody
    body = bytes
    headers.set('content-length', bytes.length.toString())
  }

  return new Request(url, {
    headers,
    method,
    body,
  })
}

export const createBody = (
  method: string,
  requestBody: CloudFrontRequest['body']
): string | Uint8Array<ArrayBuffer> | undefined => {
  if (!requestBody || !requestBody.data) {
    return undefined
  }
  if (method === 'GET' || method === 'HEAD') {
    return undefined
  }
  if (requestBody.encoding === 'base64') {
    return decodeBase64(requestBody.data)
  }
  return requestBody.data
}

export const isContentTypeBinary = (contentType: string): boolean => {
  if (/^application\/vnd\.(?:apple\.installer|mozilla\.xul)\+xml\s*(?:;|$)/i.test(contentType)) {
    return true
  }

  return !/^text\/(?:plain|html|css|javascript|csv)|(?:\/|\+)(?:json|xml)\s*(?:;|$)/i.test(
    contentType
  )
}
