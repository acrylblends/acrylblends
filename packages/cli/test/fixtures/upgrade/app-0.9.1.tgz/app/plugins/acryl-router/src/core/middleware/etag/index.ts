/**
 * @module
 * ETag Middleware for Acryl.
 */

import type { MiddlewareHandler } from '../../types.ts'
import { generateDigest } from './digest.ts'

type ETagOptions = {
  retainedHeaders?: string[]
  weak?: boolean
  generateDigest?: (body: Uint8Array<ArrayBuffer>) => ArrayBuffer | Promise<ArrayBuffer>
}

/**
 * Default headers to pass through on 304 responses. From the spec:
 * > The response must not contain a body and must include the headers that
 * > would have been sent in an equivalent 200 OK response: Cache-Control,
 * > Content-Location, Date, ETag, Expires, and Vary.
 */
export const RETAINED_304_HEADERS = [
  'cache-control',
  'content-location',
  'date',
  'etag',
  'expires',
  'vary',
]

const stripWeak = (tag: string) => tag.replace(/^W\//, '')

function etagMatches(etag: string, ifNoneMatch: string | null) {
  return (
    ifNoneMatch != null &&
    ifNoneMatch.split(',').some((t) => stripWeak(t.trim()) === stripWeak(etag))
  )
}

function initializeGenerator(
  generator?: ETagOptions['generateDigest']
): ETagOptions['generateDigest'] | undefined {
  if (!generator) {
    if (crypto && crypto.subtle) {
      generator = (body: Uint8Array<ArrayBuffer>) =>
        crypto.subtle.digest(
          {
            name: 'SHA-1',
          },
          body
        )
    }
  }

  return generator
}

/**
 * ETag Middleware for Acryl.
 *
 *
 * @param {ETagOptions} [options] - The options for the ETag middleware.
 * @param {boolean} [options.weak=false] - Define using or not using a weak validation. If true is set, then `W/` is added to the prefix of the value.
 * @param {string[]} [options.retainedHeaders=RETAINED_304_HEADERS] - The headers that you want to retain in the 304 Response.
 * @param {function(Uint8Array): ArrayBuffer | Promise<ArrayBuffer>} [options.generateDigest] -
 * A custom digest generation function. By default, it uses 'SHA-1'
 * This function is called with the response body as a `Uint8Array` and should return a hash as an `ArrayBuffer` or a Promise of one.
 * @returns {MiddlewareHandler} The middleware handler function.
 *
 * @example
 * ```ts
 * const app = new Acryl()
 *
 * app.use('/etag/*', etag())
 * app.get('/etag/abc', (c) => {
 *   return c.text('Acryl is hot')
 * })
 * ```
 */
export const etag = (options?: ETagOptions): MiddlewareHandler => {
  const retainedHeaders = new Set(
    (options?.retainedHeaders ?? RETAINED_304_HEADERS).map((header) => header.toLowerCase())
  )
  const weak = options?.weak ?? false
  const generator = initializeGenerator(options?.generateDigest)

  return async function etag(c, next) {
    const ifNoneMatch = c.req.header('If-None-Match') ?? null

    await next()

    if (
      !(c.req.method === 'GET' || c.req.method === 'HEAD' || c.req.method === 'QUERY') ||
      !c.res.ok
    ) {
      return
    }

    const res = c.res as Response
    let etag = res.headers.get('ETag')

    if (!etag) {
      if (!generator) {
        return
      }
      const hash = await generateDigest(
        // This type casing avoids the type error for `deno publish`
        res.clone().body as ReadableStream<Uint8Array<ArrayBuffer>>,
        generator
      )
      if (hash === null) {
        return
      }
      etag = weak ? `W/"${hash}"` : `"${hash}"`
    }

    const matched = ifNoneMatch === '*' || etagMatches(etag, ifNoneMatch)

    if (matched) {
      c.res = new Response(null, {
        status: 304,
        statusText: 'Not Modified',
        headers: {
          ETag: etag,
        },
      })
      for (const key of Array.from(c.res.headers.keys())) {
        if (!retainedHeaders.has(key.toLowerCase())) {
          c.res.headers.delete(key)
        }
      }
    } else {
      c.res.headers.set('ETag', etag)
    }
  }
}
